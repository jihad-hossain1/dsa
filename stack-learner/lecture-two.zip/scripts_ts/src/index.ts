import { hello } from './utils/hello';

console.log('Hello TypeScript!');
hello('TypeScript!');
