// Example of using path aliases
import { example } from '#src/utils/example.js';

console.log('Node.js project with path aliases is running!');
example();
