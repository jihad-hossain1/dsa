export const hello = (msg: string) => {
	console.log(`Hello, ${msg}`);
};
